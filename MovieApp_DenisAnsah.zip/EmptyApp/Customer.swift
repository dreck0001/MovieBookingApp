//
//  Customer.swift
//  hw4_DenisAnsah
//
//  Created by Denis on 2/16/19.
//  Copyright © 2019 DenisAnsah. All rights reserved.
//

import Foundation


struct Name {
    var first:    String
    var middle:   String?
    var last:     String
    init(first: String, middle: String?, last: String) {
        self.first  = first
        self.middle = middle
        self.last   = last
    }
    func fullName() -> String {
        if let mid = middle { return first + " " + mid + " " + last }
        else { return first + " " + last}
    }
}

struct Address {
    var houseNumber: Int
    var street: String
    var city: String
    var zip: Int
    var fullAddress: String {
        return String(houseNumber) + " " + street + "\n               " + city + ", " + String(zip) + ", " + "USA"
    }
}

struct Customer: Hashable {
    static func == (lhs: Customer, rhs: Customer) -> Bool { return lhs.id == rhs.id}
    
    var id: Int
    var name: Name
    var age: Int
    var email: String
    var address: Address
    var hashValue: Int { return id.hashValue }
    
    func displayThisCustomer() {
        let line = "-------CuatomerID: " + String(id) + "---------"
        let line2 = String(repeating: "-", count: 31)
        print("\n" + line + "\n             Name: " + name.fullName() + "\n              Age: " + String(age) + " years\n            Email: " + email + "\n          Address: " + address.fullAddress + "\n" + line2)
    }
}

extension String {
    var isAlphanumeric: Bool { return !isEmpty && range(of: "[^a-zA-Z0-9]", options: .regularExpression) == nil }
    var isAlphanumericDot: Bool { return !isEmpty && range(of: "[^a-zA-Z0-9.]", options: .regularExpression) == nil }
    var isAlphabetic: Bool { return !isEmpty && range(of: "[^a-zA-Z ]", options: .regularExpression) == nil }
    var isStrictlyAlphabetic: Bool { return !isEmpty && range(of: "[^a-zA-Z]", options: .regularExpression) == nil }
//    func indexOfChar(char: Character) -> Int {
//        for i in 0 ... self.count-1 {
//            if self. == char { return i}
//            
//        }
//    }
    var isEmailic: Bool { return !self.isEmpty && self.contains("@") && String(self.split(separator: "@")[0]).isAlphanumericDot && String(self.split(separator: "@")[1]).contains(".")}
}
//denis@yahoo.com
