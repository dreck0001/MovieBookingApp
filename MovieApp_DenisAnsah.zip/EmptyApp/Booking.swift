//
//  Booking.swift
//  hw4_DenisAnsah
//
//  Created by Denis on 2/17/19.
//  Copyright © 2019 DenisAnsah. All rights reserved.
//

import Foundation

struct Booking {
    var id: Int
    var customer: Customer
//    var quantity_movieID: [Int : Int]
    var quantity_movieID: (quantity: Int, movieID: Int)
    var bookingDate: Date { return Date.init(timeIntervalSinceNow: 0) }
    var returnDate: Date { return Date.init(timeInterval: 604800, since: bookingDate) }
    func displayThisBooking() {
        let line = "----------BookingID: " + String(id) + "-----------"
        let line2 = String(repeating: "-", count: 31)
        print("\n" + line + "\n         Customer: " + customer.name.fullName() )
        print("          MovieID: \(quantity_movieID.movieID)")
        print("     Booking Date: ", separator: "", terminator: "");  print(bookingDate)
        print("      Return Date: ", separator: "", terminator: "");  print(returnDate)
        print("Number of rentals: \(quantity_movieID.quantity)")
        print(line2)
    }
}
