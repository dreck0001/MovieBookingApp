//
//  Movie.swift
//  hw4_DenisAnsah
//
//  Created by Denis on 2/15/19.
//  Copyright © 2019 DenisAnsah. All rights reserved.
//

import Foundation

enum Type {
    case Adventure
    case Drama
    case Comedy
}

struct Movie {
    var id: Int
    var name: String
    var release: Date
    var type: Type
    var rentalsAvailable: Int
    
    func displayThisMovie () {
        let line = "----------MovieID: " + String(id) + "-----------"
        let line2 = String(repeating: "-", count: 31)
        print("\n" + line + "\n             Name: " + name )
        print("             Type: ", separator: "", terminator: ""); print(type)
        print("Rentals Available: " + String(rentalsAvailable) + "\n" + line2)
    }
}
