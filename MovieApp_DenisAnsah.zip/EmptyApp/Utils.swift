//
//  Utils.swift
//  EmptyApp
//
//  Created by denis on 2/20/19.
//  Copyright © 2019 rab. All rights reserved.
//

import Foundation
import UIKit

class Utils {
    var app = AppDelegate()
}
