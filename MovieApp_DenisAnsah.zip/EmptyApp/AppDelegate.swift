//
//  AppDelegate.swift
//  EmptyApp
//
//  Created by rab on 10/15/17.
//  Copyright © 2017 rab. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {

    

    var window: UIWindow?
    var qq = ""
    let tabHeight = CGFloat(50)
    let tabBorder = CGFloat(2)
    var tabMonitor = 0
    var dim  = CGFloat(0.4)
    var labelWidth  = CGFloat(250)
    var labelHeight = CGFloat(30)
    var fName = UITextField()
    var mName = UITextField()
    var lName = UITextField()
    var hNum = UITextField()
    var street = UITextField()
    var city = UITextField()
    var zip = UITextField()
    var age = UITextField()
    var email = UITextField()
    var movieName = UITextField()
    var movieType = UITextField()
    var movierentals = UITextField()
    var labelText = ""
    private var customers = Dictionary<Int, Customer>()
    private var movies = Dictionary<Int, Movie>()
    private var bookings = Dictionary<Int, Booking>()
    let dispCustTable = UITableView(frame: CGRect(x: 10, y: 65, width: 400, height:550), style: UITableViewStyle.grouped)
    var cellID = "theCell"
    var focus = Int()
    var deleteID = Int() {
        didSet {
            if focus == 1 { customers.removeValue(forKey: deleteID); dispCustTable.reloadData() }
            if focus == 2 { movies.removeValue(forKey: deleteID); dispCustTable.reloadData() }
            if focus == 2 { bookings.removeValue(forKey: deleteID); dispCustTable.reloadData() }
        }
    }
    var deleteMode = false
    var custID = UITextField()
    var bkID = UITextField()
    var movID = UITextField()
    var rentalsReq = UITextField()
    /////////////Helper Functions//////////////////
    func createButton(called name: String, color: UIColor) -> UIButton {
        let lastFrame = window?.subviews.last?.frame
        let theFrame: CGRect = CGRect(x: (lastFrame!.maxX)+15, y: (lastFrame!.minY), width: (lastFrame!.width)/4+30, height: (lastFrame!.height));
        let theButton = UIButton(frame: theFrame)
        theButton.setTitle(name, for: UIControlState.normal)
        theButton.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        theButton.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        theButton.layer.borderWidth = tabBorder
        theButton.backgroundColor = color
        //var t: UITableView = UITableView(frame: viewCustTab, style: UITableViewStyle.plain)
        return theButton
    }
    func createLabel (for purpose: String, withViewY viewY: CGFloat, color: UIColor) -> UILabel{
        labelText = purpose
        let label:UILabel = UILabel(frame: CGRect(x: (window?.bounds.minX)!+10, y: viewY, width:labelWidth, height:labelHeight))
        label.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        label.textColor = color
        label.text = labelText
        return label
    }
    func createTextField(for purpose: String, withViewY viewY: CGFloat, color: CGColor) -> UITextField {
        let tf = UITextField(frame: CGRect(x: (window?.bounds.minX)!+10, y: viewY, width:labelWidth, height:labelHeight))
        tf.textAlignment = NSTextAlignment.center
        tf.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        tf.backgroundColor = #colorLiteral(red: 0.9299048781, green: 0.829157114, blue: 0.7452300191, alpha: 1)
        tf.layer.borderColor = color
        tf.layer.borderWidth = tabBorder
        tf.borderStyle = UITextBorderStyle.line
        tf.autocapitalizationType = UITextAutocapitalizationType.words
        tf.clearButtonMode = .whileEditing
        tf.placeholder = purpose
        tf.delegate = self
        return tf
    }
    //////////////////////VERBS////////////////////
    func createCustomerID()  -> Int{
        var int = 1000
        while customers.keys.contains(int) { int += 1}
        return int
    }
    func createMovieID()  -> Int{
        var int = 1
        while movies.keys.contains(int) { int += 1}
        return int
    }
    func createBookingID()  -> Int{
        var int = 1
        while bookings.keys.contains(int) { int += 1}
        return int
    }
    func createCustomer(){
        let newCustID = createCustomerID()
        let newCustName = Name(first: fName.text!, middle: mName.text!, last: lName.text!)
        let newCustAddress = Address.init(houseNumber: Int(hNum.text!)!, street: street.text!, city: city.text!, zip: Int(zip.text!)!)
        let newCustomer = Customer(id: newCustID, name: newCustName, age: Int(age.text!)!, email: email.text!, address: newCustAddress)
        customers[newCustID] = newCustomer
        //show customer
        let subjectLabel = createLabel(for: "Customer Account Created!", withViewY: (window?.subviews.last?.frame.maxY)!+40, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));window?.addSubview(subjectLabel)
        let IDLabel = createLabel(for: "Customer ID: \(String(newCustomer.id))", withViewY: (window?.subviews.last?.frame.maxY)!+10, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));window?.addSubview(IDLabel)
        let nameLabel = createLabel(for: "Customer Name: " + newCustomer.name.fullName(), withViewY: (window?.subviews.last?.frame.maxY)!+10, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));window?.addSubview(nameLabel)
        let addressLabel = createLabel(for: "Customer Address: " + newCustomer.address.fullAddress, withViewY: (window?.subviews.last?.frame.maxY)!+10, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));addressLabel.numberOfLines = 3;window?.addSubview(addressLabel)
        
    }
    @objc func createCustomerEmail() {
        let v = (window?.subviews)!
        if v.count > 24 { for i in 24...v.count-1 { v[i].removeFromSuperview() } } //remove old UI
        print("validate customer email tapped")
        email.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); email.textAlignment = .center;
        if !(email.text?.isEmailic)! { email.text=""; email.placeholder = "INVALID EMAIL ADDRESS!!!"} else { print("email is good")}
        if (email.text?.isEmailic)! {
            let vv = (window?.subviews)!; print("views = \(vv.count)")

            email.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1); email.textAlignment = .left;
            print("email is valid, continue to create customer")
            createCustomer()
        }
    }
    func createEmailUI() {
        print("creating age UI")
        let emailLabel = createLabel(for: "Enter Email", withViewY: (window?.subviews.last?.frame.maxY)!+20, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));  window?.addSubview(emailLabel)
        email          = createTextField(for: "Email", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));   window?.addSubview(email)
        let custEmailValidate = createButton(called: "Validate", color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));                                            window?.addSubview(custEmailValidate)
        custEmailValidate.addTarget(self, action: #selector(createCustomerEmail), for: .touchUpInside)

    }
    @objc func createCustomerAge() {
        let v = (window?.subviews)!
        if v.count > 21 { for i in 21...v.count-1 { v[i].removeFromSuperview() } } //remove old UI
        print("validate customer age tapped")
        age.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); age.textAlignment = .center;
        if Int(age.text!) == nil || Int(age.text!)! < 18  { age.text=""; age.placeholder = "INVALID AGE!!!"}    else { print("Age is good")}
        if Int(age.text!) != nil && Int(age.text!)! >= 18 {
            let vv = (window?.subviews)!; print("views = \(vv.count)")

            age.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1); age.textAlignment = .left;
            print("age is valid, continue to create email")
            createEmailUI()
        }
    }
    func createAgeUI() {
        print("creating age UI")
        let ageLabel = createLabel(for: "Enter Age", withViewY: (window?.subviews.last?.frame.maxY)!+20, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));  window?.addSubview(ageLabel)
        age          = createTextField(for: "Age (Must be 18+)", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));   window?.addSubview(age)
        let custAgeValidate = createButton(called: "Validate", color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));                                            window?.addSubview(custAgeValidate)
        custAgeValidate.addTarget(self, action: #selector(createCustomerAge), for: .touchUpInside)
    }
    @objc func createCustomerAddress() {
        let v = (window?.subviews)!
        if v.count > 18 { for i in 18...v.count-1 { v[i].removeFromSuperview() } } //remove old UI
        print("validate customer address tapped")
        hNum.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1);          street.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1);          city.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1);          zip.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        hNum.textAlignment = .center; street.textAlignment = .center; city.textAlignment = .center; zip.textAlignment = .center;
        if Int(hNum.text!) == nil || Int(hNum.text!)! < 0       { hNum.text=""; hNum.placeholder = "INVALID HOUSE NUMBER!!!"}    else { print("House num is good")}
        if !(street.text?.isAlphabetic)! || street.text == ""   { street.text=""; street.placeholder = "INVALID STREET NAME!!!"} else { print("street is good")}
        if !(city.text?.isAlphabetic)! || city.text == ""       { city.text=""; city.placeholder = "INVALID CITY NAME!!!"}       else { print("city is good")}
        if Int(zip.text!) == nil || Int(zip.text!)! < 0 || (zip.text!).count != 5  { zip.text=""; zip.placeholder = "INVALID ZIP CODE!!!"}    else { print("zip is good")}
        if (Int(hNum.text!) != nil && Int(hNum.text!)! > 0) && ((street.text?.isAlphabetic)! && street.text != "") && ((city.text?.isAlphabetic)! && city.text != "") && (Int(zip.text!) != nil && Int(zip.text!)! > 0 && (zip.text!).count == 5) {
            let vv = (window?.subviews)!; print("views = \(vv.count)")

            hNum.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1);          street.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1) ;         city.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1);          zip.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
            hNum.textAlignment = .left; street.textAlignment = .left; city.textAlignment = .left; zip.textAlignment = .left
            print("address is valid, continue to add age")
            //create address
            let customerAddress = Address.init(houseNumber: Int(hNum.text!)!, street: street.text!, city: city.text!, zip: Int(hNum.text!)!)
            print("full address = " + customerAddress.fullAddress)
            //create age ui
            createAgeUI()
        }
    }
    func createAddressUI(){
        print("creating address UI")
        let addressLabel = createLabel(for: "Enter Full Address", withViewY: (window?.subviews.last?.frame.maxY)!+20, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));  window?.addSubview(addressLabel)
        hNum         = createTextField(for: "House Number", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));   window?.addSubview(hNum)
        street       = createTextField(for: "Street", withViewY: (window?.subviews)!.last!.frame.minY+35, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));          window?.addSubview(street)
        city         = createTextField(for: "City", withViewY:   (window?.subviews)!.last!.frame.minY+35, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));          window?.addSubview(city)
        zip          = createTextField(for: "Zip", withViewY:   (window?.subviews)!.last!.frame.minY+35, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));           window?.addSubview(zip)
        let custAddressValidate = createButton(called: "Validate", color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));                                                 window?.addSubview(custAddressValidate)
        custAddressValidate.addTarget(self, action: #selector(createCustomerAddress), for: .touchUpInside)
        //window!.addSubview(createLabel(for: "Enter Age", withViewY: (window?.subviews)!.last!.frame.minY+35))
        //window?.addSubview(createTextField(for: "Integers Only", withViewY:  (window?.subviews)!.last!.frame.minY+25))
        let vv = (window?.subviews)!
        print("views = \(vv.count)")
    }
    @objc func createCustomerName() {
        print("validate customer name tapped")
        let v = (window?.subviews)!
        if v.count > 12 { for i in 12...v.count-1 { v[i].removeFromSuperview() } } //remove old UI
        fName.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); mName.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); lName.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        fName.textAlignment = .center; mName.textAlignment = .center; lName.textAlignment = .center
        if !(fName.text?.isAlphabetic)! || fName.text == "" { fName.text=""; fName.placeholder = "INVALID FIRST NAME!!!"}
        if !(mName.text?.isAlphabetic)! && mName.text != "" { mName.text="";  mName.placeholder = "INVALID MIDDLE NAME!!!"}
        if !(lName.text?.isAlphabetic)! || lName.text == "" { lName.text="";  lName.placeholder = "INVALID LAST NAME!!!"}

        if ((fName.text?.isAlphabetic)! && fName.text != "") && ((mName.text?.isAlphabetic)! || mName.text == "") && (lName.text?.isAlphabetic)! {
            let vv = (window?.subviews)!; print("views = \(vv.count)")
            
            fName.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1); mName.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1); lName.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
            fName.textAlignment = .left; mName.textAlignment = .left; lName.textAlignment = .left
            print("customer name is valid, continue to add address")
            //create customer
            let customerName = Name(first: fName.text!, middle: mName.text, last: lName.text!)
            print("full name = " + customerName.fullName())
            //create address ui
            createAddressUI()
        }
    }
    @objc func createMovie () {
        print("validate movie tapped")
        let v = (window?.subviews)!
        if v.count > 12 { for i in 12...v.count-1 { v[i].removeFromSuperview() } } //remove old UI
        movieName.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); movieType.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); movierentals.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        movieName.textAlignment = .center; movieType.textAlignment = .center; movierentals.textAlignment = .center
        if !(movieName.text?.isAlphabetic)! || movieName.text == "" { movieName.text=""; movieName.placeholder = "INVALID NAME!!!"} else { print("Movie name is good")}
        if movieType.text?.count != 1 || !"123".contains(movieType.text!)  { movieType.text=""; movieType.placeholder = "INVALID TYPE!!!"}    else { print("Movie type is good")}
        if Int(movierentals.text!) == nil || Int(movierentals.text!)! < 0       { movierentals.text=""; movierentals.placeholder = "INVALID NUMBER OF RENTALS!!!"}    else { print("Rentals is good")}

        if (movieType.text?.count == 1 || "123".contains(movieType.text!)) && ((movieName.text?.isAlphabetic)! && movieName.text != "")  && (Int(movierentals.text!) != nil && Int(movierentals.text!)! >= 0 ) {
            
            movieName.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1); movieType.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1); movierentals.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
            movieName.textAlignment = .left; movieType.textAlignment = .left; movierentals.textAlignment = .left
            print("movie is valid, continue to create movie")
            //create movie
            let moType: Type
            switch Int(movieType.text!)! {
            case 1: moType = .Adventure
            case 2: moType = .Drama
            default: moType = .Comedy
            }
            let newMovieID = createMovieID()
            let release = Date.init()
            let newMovie = Movie(id: newMovieID, name: movieName.text!, release: release, type: moType, rentalsAvailable: Int(movierentals.text!)!)
            movies[newMovieID] = newMovie
            //show movie
            let subjectLabel = createLabel(for: "Movie Created!", withViewY: (window?.subviews.last?.frame.maxY)!+40, color: #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1));window?.addSubview(subjectLabel)
            let IDLabel = createLabel(for: "Movie ID: \(String(newMovie.id))", withViewY: (window?.subviews.last?.frame.maxY)!+10, color: #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1));window?.addSubview(IDLabel)
            let nameLabel = createLabel(for: "Movie Name: " + newMovie.name, withViewY: (window?.subviews.last?.frame.maxY)!+10, color: #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1));window?.addSubview(nameLabel)
            let typeLabel = createLabel(for: "Movie Type:  \(newMovie.type)", withViewY: (window?.subviews.last?.frame.maxY)!+10, color: #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1));typeLabel.numberOfLines = 3;window?.addSubview(typeLabel)
            let vv = (window?.subviews)!; print("views = \(vv.count)")
        }
    }
    //////////////////////CREATE////////////////////
    @objc func createCustomerIsSeleted() {
        print("create customer tapped")
        let v = (window?.subviews)!
        if v.count > 7 { for i in 7...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        v[4].alpha = 1 ; v[5].alpha = dim; v[6].alpha = dim //dim others
        
        let fn = createLabel(for: "Enter Full Name", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));             window!.addSubview(fn)
        fName = createTextField(for: "First", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));         window?.addSubview(fName)
        mName = createTextField(for: "Middle (Optional)", withViewY: (window?.subviews)!.last!.frame.minY+35, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));     window?.addSubview(mName)
        lName = createTextField(for: "Last", withViewY:   (window?.subviews)!.last!.frame.minY+35, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));     window?.addSubview(lName)
        let custNameValidate = createButton(called: "Validate", color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));                                        window?.addSubview(custNameValidate)
        custNameValidate.addTarget(self, action:#selector(self.createCustomerName), for: .touchUpInside)
        let vv = (window?.subviews)!; print("views = \(vv.count)")
    }
    @objc func createMovieIsSeleted() {
        print("create movie tapped")
        let v = (window?.subviews)!
        if v.count > 7 { for i in 7...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        v[4].alpha = 1 ; v[5].alpha = dim; v[6].alpha = dim
        let movieLabel = createLabel(for: "Create Movie", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1));             window!.addSubview(movieLabel)
        movieName = createTextField(for: "Enter Movie Name", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1));         window?.addSubview(movieName)
        movieType = createTextField(for: "Type: Adventure-1, Drama-2, Comedy-3", withViewY:  (window?.subviews)!.last!.frame.minY+35, color: #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1));         window?.addSubview(movieType)
        movierentals = createTextField(for: "Enter Rentals Available", withViewY: (window?.subviews)!.last!.frame.minY+35, color: #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1));     window?.addSubview(movierentals)
        let movieValidate = createButton(called: "Validate", color: #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1));                                   window?.addSubview(movieValidate)
        movieValidate.addTarget(self, action:#selector(self.createMovie), for: .touchUpInside)
        
        let vv = (window?.subviews)!; print("views = \(vv.count)")
    }
    
    @objc func bookingValidate() {
        print("create validate cust tapped")
        var rentalsReauestedIsGood = false
        let v = (window?.subviews)!
        if v.count > 15 { for i in 15...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        custID.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); custID.textAlignment = .center;
        movID.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); movID.textAlignment = .center;
        rentalsReq.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1); rentalsReq.textAlignment = .center;
        if custID.text == "" || Int(custID.text!) == nil || !Array(customers.keys).contains(Int(custID.text!)!)  { custID.text=""; custID.placeholder = "CUSTOMER DOESN'T EXIST!"}    else { print("customer id is good")}
        if movID.text == ""  || Int(movID.text!)  == nil || !Array(movies.keys).contains(Int(movID.text!)!)  { movID.text=""; movID.placeholder = "MOVIE DOESN'T EXIST!"}    else { print("Movie id is good")}
        if let stringRentals = rentalsReq.text { //EXISTS
            if let intRentals = Int(stringRentals) { //IS INT
                if let stringMovID = movID.text {
                    if let intMovID = Int(stringMovID) {
                        if let theMovie = movies[intMovID]{
                            if theMovie.rentalsAvailable > intRentals {
                                rentalsReauestedIsGood = true
                            } else { rentalsReq.text=""; rentalsReq.placeholder = "NOT ENOUGH RENTALS"}
                        } else { movID.text=""; movID.placeholder = "MOVIE DOESN'T EXIST"}
                    } else { movID.text=""; movID.placeholder = "VALUE MUST BE AN INT!"}
                } else { movID.text=""; movID.placeholder = "ENTER A VALUE!"}
            } else { rentalsReq.text=""; rentalsReq.placeholder = "VALUE MUST BE AN INT!"}
        } else { rentalsReq.text=""; rentalsReq.placeholder = "ENTER A VALUE!"}
        //if customers.isEmpty || movies.isEmpty || rentalsReq.text == "" || Int(rentalsReq.text) == nil || rentalsReq.text == nil || customers[Int(custID.text ?? "")!] == nil || movies[Int(movID.text ?? "")!] == nil || movies[Int(movID.text ?? "")!] == nil || (movies[Int(movID.text!)!] != nil && ((movies[Int(movID.text!)!]?.rentalsAvailable)! < Int(rentalsReq.text!)!)){ rentalsReq.text=""; rentalsReq.placeholder = "NOT ENOUGH RENTALS!"}    else { print("rentalsReq id is good")}
        if custID.text != "" && Int(custID.text!) != nil && Array(customers.keys).contains(Int(custID.text!)!) && movID.text != "" && Int(movID.text!) != nil && Array(movies.keys).contains(Int(movID.text!)!) && rentalsReq.text != "" && Int(rentalsReq.text!) != nil && (movies[Int(movID.text!)!]?.rentalsAvailable)! >= Int(rentalsReq.text!)! && rentalsReauestedIsGood {
            print("booking is valid, continue to create booking")
            custID.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1);        movID.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1);        rentalsReq.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1);
            custID.textAlignment = .left; movID.textAlignment = .left; rentalsReq.textAlignment = .left;
            let newBID = createBookingID()
            let newBooking = Booking(id: newBID, customer: customers[Int(custID.text!)!]!, quantity_movieID: (Int(rentalsReq.text!)!, Int(movID.text!)!))
            bookings[newBID] = newBooking
            movies[Int(movID.text!)!]?.rentalsAvailable -= Int(rentalsReq.text!)!
            
            let bookingConfirmLabel = createLabel(for: "Success! BookingID: \(newBID)", withViewY: (window?.subviews.last?.frame.maxY)!+40, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));window?.addSubview(bookingConfirmLabel)

            
        }
    }
    @objc func createBookingIsSeleted() {
        print("create booking tapped")
        let v = (window?.subviews)!
        if v.count > 8 { for i in 8...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        v[4].alpha = 1 ; v[5].alpha = dim; v[6].alpha = dim; v[7].alpha = dim
        let createBookCustLabel = createLabel(for: "Enter Customer ID: ", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));   window!.addSubview(createBookCustLabel)
        custID = createTextField(for: "CustomerID", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));         window?.addSubview(custID)
        let createBookMovLabel = createLabel(for: "Enter Movie ID: ", withViewY: (window?.subviews.last?.frame.maxY)!+20, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));  window?.addSubview(createBookMovLabel)
        movID = createTextField(for: "MovieID", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));   window?.addSubview(movID)
        let rentalsRequested = createLabel(for: "Enter Rentals Requested: ", withViewY: (window?.subviews.last?.frame.maxY)!+20, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));  window?.addSubview(rentalsRequested)
        rentalsReq = createTextField(for: "Num Rentals", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));   window?.addSubview(rentalsReq)
        let bookingValidate = createButton(called: "Validate", color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));  window?.addSubview(bookingValidate)
        bookingValidate.addTarget(self, action:#selector(self.bookingValidate), for: .touchUpInside)
        let vv = (window?.subviews)!; print("views = \(vv.count)")
    }
    
    //////////////////////DELETE////////////////////
    @objc func deleteCustomerIsSeleted() {
        focus = 1; deleteMode = true
        print("delete customer tapped")
        let v = (window?.subviews)!
        if v.count > 7 { for i in 7...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        let dispCustLabel = createLabel(for: "Select A Customer To Delete It", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1));   window!.addSubview(dispCustLabel)
        cellID = "cust"; dispCustTable.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
        dispCustTable.delegate = self; dispCustTable.dataSource = self; dispCustTable.reloadData(); window?.addSubview(dispCustTable)

        v[5].alpha = 1 ; v[4].alpha = dim; v[6].alpha = dim
        let vv = (window?.subviews)!
        print("views = \(vv.count)")
    }
    @objc func deleteMovieIsSeleted() {
        focus = 2; deleteMode = true
        print("delete MOVIE tapped")
        let v = (window?.subviews)!
        if v.count > 7 { for i in 7...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        let dispCustLabel = createLabel(for: "Select A Movie To Delete It", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1));   window!.addSubview(dispCustLabel)
        cellID = "mov"; dispCustTable.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
        dispCustTable.delegate = self; dispCustTable.dataSource = self; dispCustTable.reloadData(); window?.addSubview(dispCustTable)

        
        v[5].alpha = 1 ; v[4].alpha = dim; v[6].alpha = dim
        let vv = (window?.subviews)!
        print("views = \(vv.count)")
    }
    @objc func deleteBookingIsSeleted() {
        focus = 3; deleteMode = true
        print("delete Booking tapped")
        let v = (window?.subviews)!
        if v.count > 8 { for i in 8...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        let dispCustLabel = createLabel(for: "Select A Booking To Delete It", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));   window!.addSubview(dispCustLabel)
        cellID = "book"; dispCustTable.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
        dispCustTable.delegate = self; dispCustTable.dataSource = self; dispCustTable.reloadData(); window?.addSubview(dispCustTable)

        v[5].alpha = 1 ; v[4].alpha = dim; v[6].alpha = dim; v[7].alpha = dim
        let vv = (window?.subviews)!
        print("views = \(vv.count)")

    }
    //////////////////////DISPLAY////////////////////
    @objc func displayAllCustomersIsSeleted() {
        focus = 1; deleteMode = false
        print("display all customers tapped")
        let v = (window?.subviews)!
        if v.count > 7 { for i in 7...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        v[6].alpha = 1 ; v[4].alpha = dim; v[5].alpha = dim
        let dispCustLabel = createLabel(for: "All Customers", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1)); window!.addSubview(dispCustLabel)
        cellID = "cust"; dispCustTable.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
        dispCustTable.delegate = self; dispCustTable.dataSource = self; dispCustTable.reloadData(); window?.addSubview(dispCustTable)
        let vv = (window?.subviews)!; print("views = \(vv.count)")
    }
    @objc func displayAllMoviesIsSeleted() {
        focus = 2; deleteMode = false
        print("display all movie tapped")
        let v = (window?.subviews)!
        if v.count > 7 { for i in 7...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        v[6].alpha = 1 ; v[4].alpha = dim; v[5].alpha = dim
        let dispCustLabel = createLabel(for: "All Movies", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1));   window!.addSubview(dispCustLabel)
        cellID = "mov"; dispCustTable.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
        dispCustTable.delegate = self; dispCustTable.dataSource = self; dispCustTable.reloadData(); window?.addSubview(dispCustTable)
        let vv = (window?.subviews)!; print("views = \(vv.count)")
    }
    @objc func displayAllBookingsIsSeleted() {
        focus = 3; deleteMode = false
        print("display all bookings tapped")
        let v = (window?.subviews)!
        print("views = \(v.count)")
        v[6].alpha = 1 ; v[4].alpha = dim; v[5].alpha = dim; v[7].alpha = dim
        let dispCustLabel = createLabel(for: "All Bookings", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));   window!.addSubview(dispCustLabel)
        cellID = "book"; dispCustTable.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
        dispCustTable.delegate = self; dispCustTable.dataSource = self; dispCustTable.reloadData(); window?.addSubview(dispCustTable)
        let vv = (window?.subviews)!; print("views = \(vv.count)")
    }
    @objc func bookingSearch() {
        
    }
    
    @objc func searchForBooking() {
        focus = 3; deleteMode = false
        print("search booking tapped")
        let v = (window?.subviews)!
        print("views = \(v.count)")
        if v.count > 8 { for i in 8...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        v[7].alpha = 1 ; v[4].alpha = dim; v[5].alpha = dim; v[6].alpha = dim
        let searchBookingIDLabel = createLabel(for: "Enter Booking ID: ", withViewY: (window?.bounds.minY)!+40, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));   window!.addSubview(searchBookingIDLabel)
        bkID = createTextField(for: "BookingID", withViewY:  (window?.subviews)!.last!.frame.minY+25, color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));         window?.addSubview(bkID)
        
        let bookingSearch = createButton(called: "Search", color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1));  window?.addSubview(bookingSearch)
        bookingSearch.addTarget(self, action:#selector(self.bookingSearch), for: .touchUpInside)
        

        let vv = (window?.subviews)!; print("views = \(vv.count)")

    }
    //////////////////////NOUNS////////////////////
    @objc func customerIsSeleted() {
        tabMonitor = 1
        print("customer tapped")
        let v = (window?.subviews)!
        if v.count > 4 { for i in 4...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        let frameCustCreate: CGRect = CGRect(x:0, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonCustCreate = UIButton(frame: frameCustCreate)
        buttonCustCreate.setTitle("Create", for: UIControlState.normal)
        buttonCustCreate.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonCustCreate.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonCustCreate.layer.borderWidth = tabBorder
        buttonCustCreate.backgroundColor = #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1)
        buttonCustCreate.addTarget(self, action:#selector(createCustomerIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonCustCreate)
       
        let frameCustDelete: CGRect = CGRect(x:(window?.bounds.maxX)!/3, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonCustdelete = UIButton(frame: frameCustDelete)
        buttonCustdelete.setTitle("Delete", for: UIControlState.normal)
        buttonCustdelete.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonCustdelete.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonCustdelete.layer.borderWidth = tabBorder
        buttonCustdelete.backgroundColor = #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1)
        buttonCustdelete.addTarget(self, action:#selector(deleteCustomerIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonCustdelete)
        
        let frameCustDisplayAll: CGRect = CGRect(x:2*(window?.bounds.maxX)!/3, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonCustDisplayAll = UIButton(frame: frameCustDisplayAll)
        buttonCustDisplayAll.setTitle("DisplayAll", for: UIControlState.normal)
        buttonCustDisplayAll.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonCustDisplayAll.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonCustDisplayAll.layer.borderWidth = tabBorder
        buttonCustDisplayAll.backgroundColor = #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1)
        buttonCustDisplayAll.addTarget(self, action:#selector(displayAllCustomersIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonCustDisplayAll)
        v[1].alpha = 1 ; v[2].alpha = dim; v[3].alpha = dim
        let vv = (window?.subviews)!
        print("views = \(vv.count)")

    }
    @objc func bookingIsSeleted() {
        tabMonitor = 2
        print("booking tapped")
        let v = (window?.subviews)!
        if v.count > 4 { for i in 4...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        let frameBookingCreate: CGRect = CGRect(x:0, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonBookingCreate = UIButton(frame: frameBookingCreate)
        buttonBookingCreate.setTitle("Create", for: UIControlState.normal)
        buttonBookingCreate.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonBookingCreate.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonBookingCreate.layer.borderWidth = tabBorder
        buttonBookingCreate.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        buttonBookingCreate.addTarget(self, action:#selector(createBookingIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonBookingCreate)
        
        let frameBookingDelete: CGRect = CGRect(x:(window?.bounds.maxX)!/3, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonBookingdelete = UIButton(frame: frameBookingDelete)
        buttonBookingdelete.setTitle("Delete", for: UIControlState.normal)
        buttonBookingdelete.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonBookingdelete.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonBookingdelete.layer.borderWidth = tabBorder
        buttonBookingdelete.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        buttonBookingdelete.addTarget(self, action:#selector(deleteBookingIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonBookingdelete)
        
        let frameBookingDisplayAll: CGRect = CGRect(x:2*(window?.bounds.maxX)!/3, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonBookingDisplayAll = UIButton(frame: frameBookingDisplayAll)
        buttonBookingDisplayAll.setTitle("DisplayAll", for: UIControlState.normal)
        buttonBookingDisplayAll.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonBookingDisplayAll.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonBookingDisplayAll.layer.borderWidth = tabBorder
        buttonBookingDisplayAll.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        buttonBookingDisplayAll.addTarget(self, action:#selector(displayAllBookingsIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonBookingDisplayAll)
        
        let frameBookingSearch: CGRect = CGRect(x:(window?.bounds.maxX)!/3, y: (window?.bounds.maxY)!-3*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonBookingSearch = UIButton(frame: frameBookingSearch)
        buttonBookingSearch.setTitle("Search", for: UIControlState.normal)
        buttonBookingSearch.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonBookingSearch.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonBookingSearch.layer.borderWidth = tabBorder
        buttonBookingSearch.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        buttonBookingSearch.addTarget(self, action:#selector(searchForBooking), for: .touchUpInside)
        window!.addSubview(buttonBookingSearch)
        
        v[2].alpha = 1 ; v[1].alpha = dim; v[3].alpha = dim
        let vv = (window?.subviews)!
        print("views = \(vv.count)")
    }
    @objc func movieIsSeleted() {
        tabMonitor = 3
        print("movie tapped")
        let v = (window?.subviews)!
        if v.count > 4 { for i in 4...v.count-1 { v[i].removeFromSuperview() } } //remove old verbs
        let frameMovieCreate: CGRect = CGRect(x:0, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonMovieCreate = UIButton(frame: frameMovieCreate)
        buttonMovieCreate.setTitle("Create", for: UIControlState.normal)
        buttonMovieCreate.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonMovieCreate.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonMovieCreate.layer.borderWidth = tabBorder
        buttonMovieCreate.backgroundColor = #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)
        buttonMovieCreate.addTarget(self, action:#selector(createMovieIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonMovieCreate)
        
        let frameMovieDelete: CGRect = CGRect(x:(window?.bounds.maxX)!/3, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonMoviedelete = UIButton(frame: frameMovieDelete)
        buttonMoviedelete.setTitle("Delete", for: UIControlState.normal)
        buttonMoviedelete.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonMoviedelete.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonMoviedelete.layer.borderWidth = tabBorder
        buttonMoviedelete.backgroundColor = #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)
        buttonMoviedelete.addTarget(self, action:#selector(deleteMovieIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonMoviedelete)
        
        let frameMovieDisplayAll: CGRect = CGRect(x:2*(window?.bounds.maxX)!/3, y: (window?.bounds.maxY)!-2*tabHeight, width:(window?.bounds.maxX)!/3, height:tabHeight);
        let buttonMovieDisplayAll = UIButton(frame: frameMovieDisplayAll)
        buttonMovieDisplayAll.setTitle("DisplayAll", for: UIControlState.normal)
        buttonMovieDisplayAll.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
        buttonMovieDisplayAll.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        buttonMovieDisplayAll.layer.borderWidth = tabBorder
        buttonMovieDisplayAll.backgroundColor = #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)
        buttonMovieDisplayAll.addTarget(self, action:#selector(displayAllMoviesIsSeleted), for: .touchUpInside)
        window!.addSubview(buttonMovieDisplayAll)
        v[3].alpha = 1 ; v[1].alpha = dim; v[2].alpha = dim
        let vv = (window?.subviews)!
        print("views = \(vv.count)")
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        window = UIWindow(frame: UIScreen.main.bounds)
        if let window = window {
            window.backgroundColor = UIColor.black
            window.rootViewController = UIViewController()
            window.makeKeyAndVisible()
            func bbb() {}
            func trythis(){
                let wb = window.bounds
                let viewCustTab: CGRect = CGRect(x: 0,              y: wb.maxY-tabHeight, width:wb.maxX/3, height:tabHeight);
                let viewBookTab: CGRect = CGRect(x: wb.maxX/3,      y: wb.maxY-tabHeight, width:wb.maxX/3, height:tabHeight);
                let viewMovTab:  CGRect = CGRect(x: 2*wb.maxX/3,    y: wb.maxY-tabHeight, width:wb.maxX/3, height:tabHeight);
                let tabCust = UIButton(frame: viewCustTab)
                let tabBook = UIButton(frame: viewBookTab)
                let tabMov = UIButton(frame: viewMovTab)
                tabCust.setTitle("Customer", for: UIControlState.normal)
                tabBook.setTitle("Booking", for: UIControlState.normal)
                tabMov.setTitle("Movie", for: UIControlState.normal)
                tabCust.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
                tabBook.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
                tabMov.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: UIControlState.normal)
                tabCust.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
                tabBook.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
                tabMov.layer.borderColor  = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
                tabCust.layer.borderWidth = tabBorder
                tabBook.layer.borderWidth = tabBorder
                tabMov.layer.borderWidth = tabBorder
                tabCust.backgroundColor = #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1)
                tabBook.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
                tabMov.backgroundColor  = #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)
                
                tabCust.addTarget(self, action:#selector(self.customerIsSeleted), for: .touchUpInside)
                tabBook.addTarget(self, action:#selector(self.bookingIsSeleted), for: .touchUpInside)
                tabMov.addTarget(self, action:#selector(self.movieIsSeleted), for: .touchUpInside)
                
                //var t: UITableView = UITableView(frame: viewCustTab, style: UITableViewStyle.plain)
                
                
                window.addSubview(tabCust)
                window.addSubview(tabBook)
                window.addSubview(tabMov)
                //window.addSubview(t)
                
                
                let z = (window.subviews)
                print("application func started\nviews = \(z.count)")
            }
            trythis()
        }
        
        return true
    }
    //////////////////////TABLEVIEW////////////////////
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        if focus == 1 { return customers.values.count }
        if focus == 2 { return movies.values.count }
        if focus == 3 { return bookings.values.count }
        return 0
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if focus == 1 { return "Customer ID: \(Array(customers.values)[section].id)"}
        if focus == 2 { return "Movie ID: \(Array(movies.values)[section].id)                                   Available: \(Array(movies.values)[section].rentalsAvailable)"}
        if focus == 3 { return "Booking ID:  \(Array(bookings.values)[section].id)" }
        return "SOmehting Else"
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if focus == 1 {
            //let cell = dispCustTable.dequeueReusableCell(withIdentifier: "cust")
            let cell = dispCustTable.dequeueReusableCell(withIdentifier: "cust", for: indexPath)
            let this = Array(customers.values)[indexPath.section]
            cell.textLabel?.text = "Name: " + this.name.fullName() + " || Age: \(this.age)"
            return cell
        }
        if focus == 2 {
            let cell = dispCustTable.dequeueReusableCell(withIdentifier: "mov", for: indexPath)
            let this = Array(movies.values)[indexPath.section]
            cell.textLabel?.text = "Name: \(this.name)   ||   Genre: \(this.type)"
            return cell
        }
        if focus == 3 {
            let cell = dispCustTable.dequeueReusableCell(withIdentifier: "book", for: indexPath)
            let this = Array(movies.values)[indexPath.section]
            cell.textLabel?.text = "Name: \(this.name)   ||   Genre: \(this.type)"
            return cell
        }
        return dispCustTable.dequeueReusableCell(withIdentifier: "cellID")!
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        if focus == 1 { return "\(Array(customers.values)[section].email)"}
        if focus == 2 { return "Released on:    \(Array(movies.values)[section].release)"}
        if focus == 3 { return "Booked on: \(Array(bookings.values)[section].bookingDate) \nReturn Before: \(Array(bookings.values)[section].returnDate)"}
        return "nothing to show"
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var selectedID = Int()
        if deleteMode {
            if focus == 1 { selectedID = Array(customers.values)[indexPath.section].id; customers.removeValue(forKey: selectedID); }
            if focus == 2 { selectedID = Array(movies.values)[indexPath.section].id; movies.removeValue(forKey: selectedID); }
            if focus == 3 { selectedID = Array(bookings.values)[indexPath.section].id; bookings.removeValue(forKey: selectedID); }
            dispCustTable.reloadData()
            print("ID \(selectedID) deleted")
        }
    }
    //////////////////////OTHERS////////////////////
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
}

